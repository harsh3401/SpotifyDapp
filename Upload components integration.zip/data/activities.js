export const activities = [
  {
    index: 1,
    title: 'Ambient Gold',
    subTitle: 'Lo-Fi',
    avatar:
      'https://kajabi-storefronts-production.kajabi-cdn.com/kajabi-storefronts-production/themes/284832/settings_images/rLlCifhXRJiT0RoN2FjK_Logo_roundbackground_black.png',
  },
  {
    index: 2,
    title: 'Kill it anyway',
    subTitle: 'SteamBeats originals',
    avatar:
      'https://upload.wikimedia.org/wikipedia/commons/3/3b/Javascript_Logo.png',
  },
  {
    index: 3,
    title: 'Gift of a Guest',
    subTitle: 'SteamBeats originals',
    avatar: 'https://i.ytimg.com/vi/Yaeu73hr_eM/maxresdefault.jpg',
  },
]
